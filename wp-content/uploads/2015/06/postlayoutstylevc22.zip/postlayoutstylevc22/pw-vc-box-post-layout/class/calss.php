<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!class_exists('VCExtendAddonClass_BOXES')) {
	class VCExtendAddonClass_BOXES extends WPBakeryShortCode {
		
		function __construct() {
			//
			add_action( 'after_setup_theme', array( $this, 'createShortcodes' ), 5 );
			
			// We safely integrate with VC with this hook
			add_action( 'init', array( $this, 'integrateWithVC' ) );

			// Use this when creating a shortcode addon
			add_shortcode( 'pw_vc_box', array( $this, 'pw_vc_box' ) );
			
				
		}
	 
		public function integrateWithVC() {
			// Check if Visual Composer is installed
			if ( ! defined( 'WPB_VC_VERSION' ) ) {
				// Display notice that Visual Compser is required
				add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
				return;
			}
			
			add_shortcode_param('pw_number' , array($this, 'pw_number_settings_field' ) );
			add_shortcode_param('pw_image_radio',array($this,'pw_image_radio_settings_field'));
			add_shortcode_param('pw_googlefonts', array($this,'pw_googlefonts_settings_field'));
						
			//apply_filters( 'vc_shortcode_output',array($this,'vc_theme_after_vc_single_image'));
		}
		
		/*
		Add your Visual Composer logic here.
		Lets call vc_map function to "register" our custom shortcode within Visual Composer interface.
	
		More info: http://kb.wpbakery.com/index.php?title=Vc_map
		*/

		// Function generate param type "number"
		function pw_number_settings_field($settings, $value)
		{
			$dependency = vc_generate_dependencies_attributes($settings);
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$min = isset($settings['min']) ? $settings['min'] : '';
			$max = isset($settings['max']) ? $settings['max'] : '';
			$suffix = isset($settings['suffix']) ? $settings['suffix'] : '';		   
			$output = '<input type="number" min="'.$min.'" max="'.$max.'" class="wpb_vc_param_value ' . $param_name . '  " name="' . $param_name . '" value="'.$value.'" style="max-width:100px; margin-right: 10px;" />'.$suffix;
			return $output;
		}		

		public function vc_theme_after_vc_single_image($atts, $content = null) {
		   return '<div><p>Append this div before shortcode</p></div>';
		}
		
		public function pw_image_radio_settings_field($settings, $value) {
			$param_line='';
			$dependency = vc_generate_dependencies_attributes($settings);

			$param_line = '<input name="'.$settings['param_name']
					 .'" class="wpb_vc_param_value wpb-textinput '
					 .$settings['param_name'].' '.$settings['type'].' '.$settings['class'].'" id="pw_box_type" type="hidden" value="'
					 .$value.'" ' . $dependency . '/>';
					 
			$current_value =  $value;
			$values = $settings['value'];
			foreach ( $values as $label => $v ) {
				$checked = ($v==$current_value) ? ' checked="checked"' : '';
				$param_line .= ' <input style="width: auto !important;" value="' . $v . '" class="pw_box_type_radio" name="mm" type="radio" '.$checked.'> ' . __($label, "js_composer");
			}
           $param_line.= '<script type="text/javascript">
							jQuery(document).ready(function(){								
								jQuery(".pw_box_type_radio").click(function(){
									jQuery("#pw_box_type").val(jQuery(this).val());									
								});
							});
						</script>';
			
			return $param_line;
		}
		
		//GOOGLE FONTS
		function pw_get_googlefonts($selected=''){
			require PW_PS_PL_URL_BOXES_ROOT.'/inc/google-fonts.php';
			$font_options='';
			foreach($fonts_array as $key=>$value){
				$font_options.='<option '.selected($selected,$key,0).' value="'.$key.'">'.$value.'</option>';
			}
			return $font_options;
		}
		
		function pw_googlefonts_settings_field($settings, $value){
			$dependency = vc_generate_dependencies_attributes($settings);
			
			$param_line='';
			
			$param_line.='
	
			<select name="'.$settings['param_name'].'" class="wpb_vc_param_value wpb-select '
				.$settings['param_name'].' '.$settings['type'].'_field" id="'.$settings['param_name'].'-family">
				<option value="inherit">Inherit</option>
				'.$this->pw_get_googlefonts($value).'
			</select>
			
			<script type="text/javascript">
				function isNumber(n) {
				  return !isNaN(parseFloat(n)) && isFinite(n);
				}
			
				jQuery(document).ready(function(){
					
					if(jQuery("#'.$settings['param_name'].'-family").val()!="inherit")
					{
						jQuery("head").append("<link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family="+jQuery("#'.$settings['param_name'].'-family").val()+"\" />");	
						
						var $font_family=jQuery("#'.$settings['param_name'].'-family").val();
						var $font_arr=$font_family.split(":");
						if($font_arr.length>0 && isNumber($font_arr[1]))
						{
							$font_weight=$font_arr[1];
							$font_name=$font_arr[0].replace("+"," ");
							jQuery(".pw-check-font-'.$settings['param_name'].'-family").css({"font-family":$font_name,"font-weight":$font_weight});
						}else
						{
							jQuery(".pw-check-font-'.$settings['param_name'].'-family").css("font-family",jQuery("#'.$settings['param_name'].'-family").find(":selected").text());
						}
						
						jQuery(".pw-check-font-'.$settings['param_name'].'-family").css("font-family",jQuery("#'.$settings['param_name'].'-family").find(":selected").text());
					}
					
					jQuery("#'.$settings['param_name'].'-family").change(function(){
						jQuery("head").append("<link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family="+jQuery(this).val()+"\" />");	
						
						var $font_family=jQuery(this).val();
						var $font_arr=$font_family.split(":");
						if($font_arr.length>0 && isNumber($font_arr[1]))
						{
							$font_weight=$font_arr[1];
							$font_name=$font_arr[0].replace("+"," ");
							jQuery(".pw-check-font-'.$settings['param_name'].'-family").css({"font-family":$font_name,"font-weight":$font_weight});
						}else
						{
							jQuery(".pw-check-font-'.$settings['param_name'].'-family").css("font-family",jQuery(this).find(":selected").text());
						}
					});
					
				});
			
			</script>
			<p class="pw-check-font-'.$settings['param_name'].'-family">Grumpy wizards make toxic brew for the evil Queen and Jack.</p>
			
			';
			return $param_line;
		}
		

		public function pw_vc_box( $atts, $content = null ) {
			extract( shortcode_atts( array(
				'pw_title'							  => '',
				'pw_query'							  => 'size:5|order_by:date|order:ASC|post_type:posts',				
				'pw_link_target'						=> 'slider',
				'pw_post_layout'						=> '',
				
				'pw_border_top_size'                    => '',
				'pw_border_top_type'                    => '',
				'pw_border_top_color'                   => '',
			
				'pw_border_right_size'                  => '',
				'pw_border_right_type'                  => '',
				'pw_border_right_color'                 => '',
				
				'pw_border_bottom_size'                 => '',
				'pw_border_bottom_type'                 => '',
				'pw_border_bottom_color'                => '',
				
				'pw_border_left_size'                   => '',
				'pw_border_left_type'                   => '',
				'pw_border_left_color'                  => '',
				
				'pw_item_border_size'                   => '',
				'pw_item_border_type'                   => '',
				'pw_item_border_color'                  => '',
				
				'pw_back_color'                      	 => '#ffffff',
				'pw_item_back_color'                    => '',
				'pw_item_height'                     	=> '',
				
				'pw_thumb_border_color'                 => '',
				
				'pw_title_font_family'					=>'',
				'pw_title_font_size'					=>'14',			
				'pw_link_color'                         => '',
				'pw_link_hover_color'                   => '',
				'pw_meta_font_family'					=>'',
				'pw_meta_font_size'						=>'12',
				'pw_meta_color'                         => '',
				'pw_excerpt_font_family'				=>'',
				'pw_excerpt_font_size'					=>'11',
				'pw_excerpt_color'                      => '',
				'pw_readmore_type'                      => '',
				'pw_readmore_translate'                 => __('Read More',__PW_POST_LAYOUT_TEXTDOMAN__ ),
				
				'pw_box_carousel_item'                  => '',
				'pw_box_speed'                          => '',
				'pw_box_carousel_pre_view'              => '3',
				'pw_box_slider_hide_prev_next_buttons'  => 'no',
				'pw_box_slider_loop'                    => 'yes',
				
				'pw_grid_type'					      => 'pl-standard-grid',
				'pw_grid_desktop_columns_count'		 => 'pl-col-md-12',
				'pw_grid_tablet_columns_count'		  => 'pl-col-sm-12',
				'pw_grid_mobile_columns_count'		  => 'pl-col-xs-12',
				'pw_skin_type'			              => 'pl-gridskin-one',
				'pw_grid_skin_effect'				   => 'pl-gst-effect-1',
				'pw_grid_page_navigation'			   => '100%',
				'pw_grid_filter_by'					 => '',
				'pw_grid_order_by'					  => '',
				'pw_list_type'					      => '',
				'pw_marquee_type'					   => '',
				'pw_marquee_position'				   => '',
				'pw_marquee_height'				     => '',
				'pw_marquee_border_size'	     		=> '',
				'pw_marquee_border_radius'	     	  => '',
				'pw_marquee_border_type'	     		=> '',
				'pw_marquee_border_color'	     	   => '',
				'pw_marquee_direction'	     		  => '',
				'pw_marquee_title_fontsize'	     	 => '',
				'pw_marquee_title_width'	     	    => '',
				'pw_marquee_title_background'           => '', 
				'pw_marquee_content_background'         => '',
				'pw_marquee_content_fontsize'	       => '',
				'pw_marquee_content_showdate'	       => '',
				'pw_hide_date'         		       		=> 'off', //default:hide
				'pw_date_format'	      				=> 'D m',
				'pw_marquee_text_colour'			    => '',
				'pw_marquee_text_colour_hover'		  => '',
				'pw_text_align'				         => '',
				'pw_teasr_layout_img'				   => '',
				'pw_image_thumb_size'				   => 'medium',
				'pw_excerpt_length'				     => '20',
				'pw_carousel_pre_view'				  => '',
				'pw_image_effect'					   => '',
				'pw_show_zoom_icon'		      	        => 'no',
				'pw_show_link_icon'		      	        => 'no',
				'pw_icon_type'		      	       		=> '',
				'pw_icon_effect'		      	        => '',
				'pw_overlay'					        => '',
				'pw_box_type'						   => '',
				
				'pw_image_type'					     => '',
				'pw_image_carousel_item'			    => '',
				'pw_image_carousel_pre_view'		    => '',
				'pw_image_speed'					    => '1000',
				'pw_image_slider_hide_prev_next_buttons'=> 'no',
				'pw_image_slider_loop'				  => 'yes',
				'pw_image_columns_count'				=> '3',
				
				'pw_speed'							  => '2000',
				'pw_slider_caption_type'				=> '',
				'pw_slider_type'						=> '',
				'pw_slider_elastic_animation'		   => '',
				'pw_slider_hide_pagination_control'	 => 'no',
				'pw_slider_hide_prev_next_buttons'	  => 'no',
				'pw_slider_loop'					    => 'yes',
				'pw_hide_excerpt'					   => 'no',
				'pw_hide_readmore'					  => 'no',
				'pw_marquee_icon'					   => '',
				'pw_slider_overlay_background'          => '',
				'pw_slider_link_fontsize'       		   => '',
				'pw_slider_excerpt_fontsize'            => '',
				'pw_box_item_hide_excerpt'              => 'no',

			), $atts ) );
			$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content
			
			//global 
			$GLOBALS['output']="";
			
			//SET DEFAULT VALUE TO CHECKBOX
			$pw_box_slider_hide_prev_next_buttons 	= ($pw_box_slider_hide_prev_next_buttons!='' ? $pw_box_slider_hide_prev_next_buttons :'no');
			$pw_box_slider_loop 	= ($pw_box_slider_loop!='' ? $pw_box_slider_loop :'yes');
			$pw_hide_date 	= ($pw_hide_date!='' ? $pw_hide_date :'off');
			$pw_show_zoom_icon 	= ($pw_show_zoom_icon!='' ? $pw_show_zoom_icon :'no');
			$pw_show_link_icon 	= ($pw_show_link_icon!='' ? $pw_show_link_icon :'no');
			$pw_image_slider_hide_prev_next_buttons 	= ($pw_image_slider_hide_prev_next_buttons!='' ? $pw_image_slider_hide_prev_next_buttons :'no');
			$pw_image_slider_loop 	= ($pw_image_slider_loop!='' ? $pw_image_slider_loop :'yes');
			$pw_slider_hide_pagination_control 	= ($pw_slider_hide_pagination_control!='' ? $pw_slider_hide_pagination_control :'no');
			$pw_slider_hide_prev_next_buttons 	= ($pw_slider_hide_prev_next_buttons!='' ? $pw_slider_hide_prev_next_buttons :'no');
			$pw_hide_excerpt 	= ($pw_hide_excerpt!='' ? $pw_hide_excerpt :'no');
			$pw_hide_readmore 	= ($pw_hide_readmore!='' ? $pw_hide_readmore :'no');
			$pw_box_item_hide_excerpt 	= ($pw_box_item_hide_excerpt!='' ? $pw_box_item_hide_excerpt :'no');

			$slider_class = new VC_PW_boxes(
				$pw_title,
				$pw_query,
				$pw_link_target,
				$pw_teasr_layout_img,
				$pw_image_thumb_size,
				$pw_excerpt_length,
				$pw_image_effect,
				$pw_show_zoom_icon,
				$pw_show_link_icon,
				$pw_icon_type,
				$pw_icon_effect,
				
				$pw_box_type,
				$pw_border_top_size,
				$pw_border_top_type,
				$pw_border_top_color,
				
				$pw_border_right_size,
				$pw_border_right_type,
				$pw_border_right_color,
				
				$pw_border_bottom_size,
				$pw_border_bottom_type,
				$pw_border_bottom_color,
				
				$pw_border_left_size,
				$pw_border_left_type,
				$pw_border_left_color,
				
				$pw_item_border_size,
				$pw_item_border_type,
				$pw_item_border_color,
				
				$pw_back_color,
				$pw_item_back_color,
				
				$pw_thumb_border_color,
				
				$pw_title_font_family,
				$pw_title_font_size,
				$pw_link_color,
				$pw_link_hover_color,
				$pw_meta_font_family,
				$pw_meta_font_size,
				$pw_meta_color,
				$pw_excerpt_font_family,
				$pw_excerpt_font_size,
				$pw_excerpt_color,
				$pw_readmore_type,
				$pw_readmore_translate,
				
				$pw_box_carousel_item,
				$pw_box_speed,
				$pw_box_carousel_pre_view,
				$pw_box_slider_hide_prev_next_buttons,
				$pw_box_slider_loop,
				$pw_hide_date,
				$pw_date_format,
				$pw_box_item_hide_excerpt
				
			);
			
			return $GLOBALS['output'];
		}

		public function createShortcodes() {	

			require_once("admin-ui.php");						
		}
		
		public function excerpt($excerpt,$limit) {
			$excerpt = explode(' ', $excerpt, $limit);
			if (count($excerpt)>=$limit) {
				array_pop($excerpt);
				$excerpt = implode(" ",$excerpt).'...';
			} else {
				$excerpt = implode(" ",$excerpt);
			} 
			$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
			return $excerpt;
		}

	}
	// Finally initialize code
	$GLOBALS['VCExtendAddonClass_BOXES'] = new VCExtendAddonClass_BOXES;
}

?>